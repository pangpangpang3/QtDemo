#include "mainwindow.h"

#include <QLabel>
#include <QtSvg/qsvgrenderer.h>
#include <QPainter>
MainWindow::MainWindow(QWidget *parent)
    : QFrame(parent)
{
    this->setStyleSheet("QFrame{background-color:rgba(0, 0, 0, 0);}");


    QString path =":/img/timeline.svg";
    QPixmap pix(path);

    QSvgRenderer renderer(path);
    pix.fill(Qt::transparent);
    QPainter painter;
    painter.begin(&pix);
    renderer.render(&painter);
    painter.end();

    QLabel* m_timeLabel = new QLabel(this);
    m_timeLabel->move(50, 50);
    m_timeLabel->setFixedSize(15, 16);
    m_timeLabel->setPixmap(pix);

}

MainWindow::~MainWindow()
{

}
