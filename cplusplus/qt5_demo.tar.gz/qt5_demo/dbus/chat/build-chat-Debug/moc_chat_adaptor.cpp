/****************************************************************************
** Meta object code from reading C++ file 'chat_adaptor.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.4.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "chat_adaptor.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'chat_adaptor.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.4.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_ChatAdaptor_t {
    QByteArrayData data[10];
    char stringdata[480];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ChatAdaptor_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ChatAdaptor_t qt_meta_stringdata_ChatAdaptor = {
    {
QT_MOC_LITERAL(0, 0, 11), // "ChatAdaptor"
QT_MOC_LITERAL(1, 12, 15), // "D-Bus Interface"
QT_MOC_LITERAL(2, 28, 16), // "org.example.chat"
QT_MOC_LITERAL(3, 45, 19), // "D-Bus Introspection"
QT_MOC_LITERAL(4, 65, 384), // "  <interface name=\"org.examp..."
QT_MOC_LITERAL(5, 410, 6), // "action"
QT_MOC_LITERAL(6, 417, 0), // ""
QT_MOC_LITERAL(7, 418, 8), // "nickname"
QT_MOC_LITERAL(8, 427, 4), // "text"
QT_MOC_LITERAL(9, 432, 7) // "message"

    },
    "ChatAdaptor\0D-Bus Interface\0"
    "org.example.chat\0D-Bus Introspection\0"
    "  <interface name=\"org.example.chat\">\n    <signal name=\"message\">"
    "\n      <arg direction=\"out\" type=\"s\" name=\"nickname\"/>\n      <"
    "arg direction=\"out\" type=\"s\" name=\"text\"/>\n    </signal>\n    <"
    "signal name=\"action\">\n      <arg direction=\"out\" type=\"s\" name="
    "\"nickname\"/>\n      <arg direction=\"out\" type=\"s\" name=\"text\"/"
    ">\n    </signal>\n  </interface>\n\0"
    "action\0\0nickname\0text\0message"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ChatAdaptor[] = {

 // content:
       7,       // revision
       0,       // classname
       2,   14, // classinfo
       2,   18, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // classinfo: key, value
       1,    2,
       3,    4,

 // signals: name, argc, parameters, tag, flags
       5,    2,   28,    6, 0x06 /* Public */,
       9,    2,   33,    6, 0x06 /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    7,    8,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    7,    8,

       0        // eod
};

void ChatAdaptor::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        ChatAdaptor *_t = static_cast<ChatAdaptor *>(_o);
        switch (_id) {
        case 0: _t->action((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 1: _t->message((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (ChatAdaptor::*_t)(const QString & , const QString & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ChatAdaptor::action)) {
                *result = 0;
            }
        }
        {
            typedef void (ChatAdaptor::*_t)(const QString & , const QString & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ChatAdaptor::message)) {
                *result = 1;
            }
        }
    }
}

const QMetaObject ChatAdaptor::staticMetaObject = {
    { &QDBusAbstractAdaptor::staticMetaObject, qt_meta_stringdata_ChatAdaptor.data,
      qt_meta_data_ChatAdaptor,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *ChatAdaptor::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ChatAdaptor::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_ChatAdaptor.stringdata))
        return static_cast<void*>(const_cast< ChatAdaptor*>(this));
    return QDBusAbstractAdaptor::qt_metacast(_clname);
}

int ChatAdaptor::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDBusAbstractAdaptor::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 2)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 2;
    }
    return _id;
}

// SIGNAL 0
void ChatAdaptor::action(const QString & _t1, const QString & _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void ChatAdaptor::message(const QString & _t1, const QString & _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_END_MOC_NAMESPACE
