/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.4.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../graphicsview/diagramscene/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.4.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[32];
    char stringdata[436];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 28), // "backgroundButtonGroupClicked"
QT_MOC_LITERAL(2, 40, 0), // ""
QT_MOC_LITERAL(3, 41, 16), // "QAbstractButton*"
QT_MOC_LITERAL(4, 58, 6), // "button"
QT_MOC_LITERAL(5, 65, 18), // "buttonGroupClicked"
QT_MOC_LITERAL(6, 84, 2), // "id"
QT_MOC_LITERAL(7, 87, 10), // "deleteItem"
QT_MOC_LITERAL(8, 98, 19), // "pointerGroupClicked"
QT_MOC_LITERAL(9, 118, 12), // "bringToFront"
QT_MOC_LITERAL(10, 131, 10), // "sendToBack"
QT_MOC_LITERAL(11, 142, 12), // "itemInserted"
QT_MOC_LITERAL(12, 155, 12), // "DiagramItem*"
QT_MOC_LITERAL(13, 168, 4), // "item"
QT_MOC_LITERAL(14, 173, 12), // "textInserted"
QT_MOC_LITERAL(15, 186, 18), // "QGraphicsTextItem*"
QT_MOC_LITERAL(16, 205, 18), // "currentFontChanged"
QT_MOC_LITERAL(17, 224, 4), // "font"
QT_MOC_LITERAL(18, 229, 15), // "fontSizeChanged"
QT_MOC_LITERAL(19, 245, 4), // "size"
QT_MOC_LITERAL(20, 250, 17), // "sceneScaleChanged"
QT_MOC_LITERAL(21, 268, 5), // "scale"
QT_MOC_LITERAL(22, 274, 16), // "textColorChanged"
QT_MOC_LITERAL(23, 291, 16), // "itemColorChanged"
QT_MOC_LITERAL(24, 308, 16), // "lineColorChanged"
QT_MOC_LITERAL(25, 325, 19), // "textButtonTriggered"
QT_MOC_LITERAL(26, 345, 19), // "fillButtonTriggered"
QT_MOC_LITERAL(27, 365, 19), // "lineButtonTriggered"
QT_MOC_LITERAL(28, 385, 16), // "handleFontChange"
QT_MOC_LITERAL(29, 402, 12), // "itemSelected"
QT_MOC_LITERAL(30, 415, 14), // "QGraphicsItem*"
QT_MOC_LITERAL(31, 430, 5) // "about"

    },
    "MainWindow\0backgroundButtonGroupClicked\0"
    "\0QAbstractButton*\0button\0buttonGroupClicked\0"
    "id\0deleteItem\0pointerGroupClicked\0"
    "bringToFront\0sendToBack\0itemInserted\0"
    "DiagramItem*\0item\0textInserted\0"
    "QGraphicsTextItem*\0currentFontChanged\0"
    "font\0fontSizeChanged\0size\0sceneScaleChanged\0"
    "scale\0textColorChanged\0itemColorChanged\0"
    "lineColorChanged\0textButtonTriggered\0"
    "fillButtonTriggered\0lineButtonTriggered\0"
    "handleFontChange\0itemSelected\0"
    "QGraphicsItem*\0about"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      20,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,  114,    2, 0x08 /* Private */,
       5,    1,  117,    2, 0x08 /* Private */,
       7,    0,  120,    2, 0x08 /* Private */,
       8,    1,  121,    2, 0x08 /* Private */,
       9,    0,  124,    2, 0x08 /* Private */,
      10,    0,  125,    2, 0x08 /* Private */,
      11,    1,  126,    2, 0x08 /* Private */,
      14,    1,  129,    2, 0x08 /* Private */,
      16,    1,  132,    2, 0x08 /* Private */,
      18,    1,  135,    2, 0x08 /* Private */,
      20,    1,  138,    2, 0x08 /* Private */,
      22,    0,  141,    2, 0x08 /* Private */,
      23,    0,  142,    2, 0x08 /* Private */,
      24,    0,  143,    2, 0x08 /* Private */,
      25,    0,  144,    2, 0x08 /* Private */,
      26,    0,  145,    2, 0x08 /* Private */,
      27,    0,  146,    2, 0x08 /* Private */,
      28,    0,  147,    2, 0x08 /* Private */,
      29,    1,  148,    2, 0x08 /* Private */,
      31,    0,  151,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, QMetaType::Int,    6,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    6,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 12,   13,
    QMetaType::Void, 0x80000000 | 15,   13,
    QMetaType::Void, QMetaType::QFont,   17,
    QMetaType::Void, QMetaType::QString,   19,
    QMetaType::Void, QMetaType::QString,   21,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 30,   13,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        switch (_id) {
        case 0: _t->backgroundButtonGroupClicked((*reinterpret_cast< QAbstractButton*(*)>(_a[1]))); break;
        case 1: _t->buttonGroupClicked((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->deleteItem(); break;
        case 3: _t->pointerGroupClicked((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->bringToFront(); break;
        case 5: _t->sendToBack(); break;
        case 6: _t->itemInserted((*reinterpret_cast< DiagramItem*(*)>(_a[1]))); break;
        case 7: _t->textInserted((*reinterpret_cast< QGraphicsTextItem*(*)>(_a[1]))); break;
        case 8: _t->currentFontChanged((*reinterpret_cast< const QFont(*)>(_a[1]))); break;
        case 9: _t->fontSizeChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 10: _t->sceneScaleChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 11: _t->textColorChanged(); break;
        case 12: _t->itemColorChanged(); break;
        case 13: _t->lineColorChanged(); break;
        case 14: _t->textButtonTriggered(); break;
        case 15: _t->fillButtonTriggered(); break;
        case 16: _t->lineButtonTriggered(); break;
        case 17: _t->handleFontChange(); break;
        case 18: _t->itemSelected((*reinterpret_cast< QGraphicsItem*(*)>(_a[1]))); break;
        case 19: _t->about(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 7:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QGraphicsTextItem* >(); break;
            }
            break;
        case 18:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QGraphicsItem* >(); break;
            }
            break;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 20)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 20;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 20)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 20;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
