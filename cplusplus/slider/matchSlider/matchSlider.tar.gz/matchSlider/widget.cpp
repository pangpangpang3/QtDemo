#include "widget.h"
#include "sliderframe.h"

#include <QDebug>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    SliderFrame* sliderFrame = new SliderFrame(this);
    sliderFrame->move(10, 20);
    sliderFrame->setFixedSize(100, 400);
    connect(sliderFrame, &SliderFrame::valueChanged, [=]{
        sliderFrame->setCurrentInfo("$$$$$$$$", 2);
        qDebug() << "slider frame value changed!";
    });
}

Widget::~Widget()
{

}
