.. currentmodule:: PyQt5.QtWidgets

QSplashScreen
-------------

.. class:: QSplashScreen

    `C++ documentation <http://qt-project.org/doc/qt-5/qsplashscreen.html>`_
