.. currentmodule:: PyQt5.QtSensors

QSensorReading
--------------

.. class:: QSensorReading

    `C++ documentation <http://qt-project.org/doc/qt-5/qsensorreading.html>`_
