.. currentmodule:: PyQt5.QtWidgets

QGraphicsLayoutItem
-------------------

.. class:: QGraphicsLayoutItem

    `C++ documentation <http://qt-project.org/doc/qt-5/qgraphicslayoutitem.html>`_
