.. currentmodule:: PyQt5.QtWidgets

QListWidgetItem
---------------

.. class:: QListWidgetItem

    `C++ documentation <http://qt-project.org/doc/qt-5/qlistwidgetitem.html>`_
