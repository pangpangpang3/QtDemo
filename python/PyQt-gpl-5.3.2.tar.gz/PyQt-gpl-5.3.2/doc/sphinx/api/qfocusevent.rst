.. currentmodule:: PyQt5.QtGui

QFocusEvent
-----------

.. class:: QFocusEvent

    `C++ documentation <http://qt-project.org/doc/qt-5/qfocusevent.html>`_
