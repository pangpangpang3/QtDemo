.. currentmodule:: PyQt5.QtBluetooth

QBluetoothLocalDevice
---------------------

.. class:: QBluetoothLocalDevice

    `C++ documentation <http://qt-project.org/doc/qt-5/qbluetoothlocaldevice.html>`_
