.. currentmodule:: PyQt5.QtNetwork

QHostInfo
---------

.. class:: QHostInfo

    `C++ documentation <http://qt-project.org/doc/qt-5/qhostinfo.html>`_
