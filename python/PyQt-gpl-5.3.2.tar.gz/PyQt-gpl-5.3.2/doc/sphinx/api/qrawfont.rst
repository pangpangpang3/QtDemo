.. currentmodule:: PyQt5.QtGui

QRawFont
--------

.. class:: QRawFont

    `C++ documentation <http://qt-project.org/doc/qt-5/qrawfont.html>`_
