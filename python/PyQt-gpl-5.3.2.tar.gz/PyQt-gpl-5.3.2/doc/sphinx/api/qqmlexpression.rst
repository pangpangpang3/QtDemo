.. currentmodule:: PyQt5.QtQml

QQmlExpression
--------------

.. class:: QQmlExpression

    `C++ documentation <http://qt-project.org/doc/qt-5/qqmlexpression.html>`_
