.. currentmodule:: PyQt5.QtGui

QCloseEvent
-----------

.. class:: QCloseEvent

    `C++ documentation <http://qt-project.org/doc/qt-5/qcloseevent.html>`_
