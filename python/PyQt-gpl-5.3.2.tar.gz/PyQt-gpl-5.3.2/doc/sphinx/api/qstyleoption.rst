.. currentmodule:: PyQt5.QtWidgets

QStyleOption
------------

.. class:: QStyleOption

    `C++ documentation <http://qt-project.org/doc/qt-5/qstyleoption.html>`_
