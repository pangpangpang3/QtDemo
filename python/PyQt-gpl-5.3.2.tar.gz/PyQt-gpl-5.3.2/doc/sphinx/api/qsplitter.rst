.. currentmodule:: PyQt5.QtWidgets

QSplitter
---------

.. class:: QSplitter

    `C++ documentation <http://qt-project.org/doc/qt-5/qsplitter.html>`_
