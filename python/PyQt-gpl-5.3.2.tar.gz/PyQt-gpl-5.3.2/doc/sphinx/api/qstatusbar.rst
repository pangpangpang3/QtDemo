.. currentmodule:: PyQt5.QtWidgets

QStatusBar
----------

.. class:: QStatusBar

    `C++ documentation <http://qt-project.org/doc/qt-5/qstatusbar.html>`_
