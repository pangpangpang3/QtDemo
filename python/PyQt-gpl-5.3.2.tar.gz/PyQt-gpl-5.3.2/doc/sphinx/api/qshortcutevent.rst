.. currentmodule:: PyQt5.QtGui

QShortcutEvent
--------------

.. class:: QShortcutEvent

    `C++ documentation <http://qt-project.org/doc/qt-5/qshortcutevent.html>`_
