.. currentmodule:: PyQt5.QtDesigner

QDesignerMemberSheetExtension
-----------------------------

.. class:: QDesignerMemberSheetExtension

    `C++ documentation <http://qt-project.org/doc/qt-5/qdesignermembersheetextension.html>`_
