.. currentmodule:: PyQt5.QtSql

QSqlDriver
----------

.. class:: QSqlDriver

    `C++ documentation <http://qt-project.org/doc/qt-5/qsqldriver.html>`_
