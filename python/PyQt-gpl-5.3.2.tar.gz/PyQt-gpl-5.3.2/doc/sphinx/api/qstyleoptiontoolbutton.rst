.. currentmodule:: PyQt5.QtWidgets

QStyleOptionToolButton
----------------------

.. class:: QStyleOptionToolButton

    `C++ documentation <http://qt-project.org/doc/qt-5/qstyleoptiontoolbutton.html>`_
