.. currentmodule:: PyQt5.QtXmlPatterns

QAbstractXmlNodeModel
---------------------

.. class:: QAbstractXmlNodeModel

    `C++ documentation <http://qt-project.org/doc/qt-5/qabstractxmlnodemodel.html>`_
