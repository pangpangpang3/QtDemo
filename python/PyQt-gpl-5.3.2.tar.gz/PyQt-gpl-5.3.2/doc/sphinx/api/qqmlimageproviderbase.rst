.. currentmodule:: PyQt5.QtQml

QQmlImageProviderBase
---------------------

.. class:: QQmlImageProviderBase

    `C++ documentation <http://qt-project.org/doc/qt-5/qqmlimageproviderbase.html>`_
