.. currentmodule:: PyQt5.QtSensors

QCompassFilter
--------------

.. class:: QCompassFilter

    `C++ documentation <http://qt-project.org/doc/qt-5/qcompassfilter.html>`_
