.. currentmodule:: PyQt5.QtMultimedia

QMediaPlaylist
--------------

.. class:: QMediaPlaylist

    `C++ documentation <http://qt-project.org/doc/qt-5/qmediaplaylist.html>`_
