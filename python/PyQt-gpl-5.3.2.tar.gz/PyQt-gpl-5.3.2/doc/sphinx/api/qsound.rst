.. currentmodule:: PyQt5.QtMultimedia

QSound
------

.. class:: QSound

    `C++ documentation <http://qt-project.org/doc/qt-5/qsound.html>`_
