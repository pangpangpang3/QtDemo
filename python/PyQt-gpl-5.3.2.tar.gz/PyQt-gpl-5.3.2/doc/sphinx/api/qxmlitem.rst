.. currentmodule:: PyQt5.QtXmlPatterns

QXmlItem
--------

.. class:: QXmlItem

    `C++ documentation <http://qt-project.org/doc/qt-5/qxmlitem.html>`_
