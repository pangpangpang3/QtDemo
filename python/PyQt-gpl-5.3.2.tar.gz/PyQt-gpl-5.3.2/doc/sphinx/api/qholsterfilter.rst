.. currentmodule:: PyQt5.QtSensors

QHolsterFilter
--------------

.. class:: QHolsterFilter

    `C++ documentation <http://qt-project.org/doc/qt-5/qholsterfilter.html>`_
