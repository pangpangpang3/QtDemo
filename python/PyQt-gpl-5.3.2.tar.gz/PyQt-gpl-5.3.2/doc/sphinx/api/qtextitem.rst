.. currentmodule:: PyQt5.QtGui

QTextItem
---------

.. class:: QTextItem

    `C++ documentation <http://qt-project.org/doc/qt-5/qtextitem.html>`_
