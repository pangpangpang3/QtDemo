.. currentmodule:: PyQt5.QtPositioning

QGeoPositionInfoSource
----------------------

.. class:: QGeoPositionInfoSource

    `C++ documentation <http://qt-project.org/doc/qt-5/qgeopositioninfosource.html>`_
