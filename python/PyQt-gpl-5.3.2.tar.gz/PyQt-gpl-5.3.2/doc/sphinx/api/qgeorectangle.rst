.. currentmodule:: PyQt5.QtPositioning

QGeoRectangle
-------------

.. class:: QGeoRectangle

    `C++ documentation <http://qt-project.org/doc/qt-5/qgeorectangle.html>`_
