.. currentmodule:: PyQt5.QtWidgets

QCompleter
----------

.. class:: QCompleter

    `C++ documentation <http://qt-project.org/doc/qt-5/qcompleter.html>`_
