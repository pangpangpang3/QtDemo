.. currentmodule:: PyQt5.QtWebKit

QWebPluginFactory
-----------------

.. class:: QWebPluginFactory

    `C++ documentation <http://qt-project.org/doc/qt-5/qwebpluginfactory.html>`_
