.. currentmodule:: PyQt5.QtCore

QSharedMemory
-------------

.. class:: QSharedMemory

    `C++ documentation <http://qt-project.org/doc/qt-5/qsharedmemory.html>`_
