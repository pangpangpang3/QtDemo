.. currentmodule:: PyQt5.QtMultimedia

QMediaRecorder
--------------

.. class:: QMediaRecorder

    `C++ documentation <http://qt-project.org/doc/qt-5/qmediarecorder.html>`_
