.. currentmodule:: PyQt5.QtWidgets

QGraphicsSceneMouseEvent
------------------------

.. class:: QGraphicsSceneMouseEvent

    `C++ documentation <http://qt-project.org/doc/qt-5/qgraphicsscenemouseevent.html>`_
