.. currentmodule:: PyQt5.QtCore

QSaveFile
---------

.. class:: QSaveFile

    `C++ documentation <http://qt-project.org/doc/qt-5/qsavefile.html>`_
