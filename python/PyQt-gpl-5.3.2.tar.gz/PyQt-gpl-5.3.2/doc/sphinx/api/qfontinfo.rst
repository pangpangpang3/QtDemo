.. currentmodule:: PyQt5.QtGui

QFontInfo
---------

.. class:: QFontInfo

    `C++ documentation <http://qt-project.org/doc/qt-5/qfontinfo.html>`_
