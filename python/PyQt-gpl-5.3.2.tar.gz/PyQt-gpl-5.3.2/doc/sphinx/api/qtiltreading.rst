.. currentmodule:: PyQt5.QtSensors

QTiltReading
------------

.. class:: QTiltReading

    `C++ documentation <http://qt-project.org/doc/qt-5/qtiltreading.html>`_
