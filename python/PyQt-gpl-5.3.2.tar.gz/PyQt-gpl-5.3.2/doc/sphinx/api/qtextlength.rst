.. currentmodule:: PyQt5.QtGui

QTextLength
-----------

.. class:: QTextLength

    `C++ documentation <http://qt-project.org/doc/qt-5/qtextlength.html>`_
