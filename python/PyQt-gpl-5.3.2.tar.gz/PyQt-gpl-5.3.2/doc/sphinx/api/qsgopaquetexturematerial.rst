.. currentmodule:: PyQt5.QtQuick

QSGOpaqueTextureMaterial
------------------------

.. class:: QSGOpaqueTextureMaterial

    `C++ documentation <http://qt-project.org/doc/qt-5/qsgopaquetexturematerial.html>`_
