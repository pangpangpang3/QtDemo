.. currentmodule:: PyQt5.QtWidgets

QStyleOptionButton
------------------

.. class:: QStyleOptionButton

    `C++ documentation <http://qt-project.org/doc/qt-5/qstyleoptionbutton.html>`_
