.. currentmodule:: PyQt5.QtGui

QColor
------

.. class:: QColor

    `C++ documentation <http://qt-project.org/doc/qt-5/qcolor.html>`_
