.. currentmodule:: PyQt5.QtCore

QTextStreamManipulator
----------------------

.. class:: QTextStreamManipulator

    `C++ documentation <http://qt-project.org/doc/qt-5/qtextstreammanipulator.html>`_
