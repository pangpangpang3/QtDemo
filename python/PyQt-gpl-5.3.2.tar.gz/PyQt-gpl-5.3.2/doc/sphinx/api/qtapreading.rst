.. currentmodule:: PyQt5.QtSensors

QTapReading
-----------

.. class:: QTapReading

    `C++ documentation <http://qt-project.org/doc/qt-5/qtapreading.html>`_
