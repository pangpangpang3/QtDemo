.. currentmodule:: PyQt5.QtWidgets

QTableWidgetItem
----------------

.. class:: QTableWidgetItem

    `C++ documentation <http://qt-project.org/doc/qt-5/qtablewidgetitem.html>`_
