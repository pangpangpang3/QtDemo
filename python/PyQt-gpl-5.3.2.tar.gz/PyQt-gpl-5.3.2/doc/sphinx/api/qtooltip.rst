.. currentmodule:: PyQt5.QtWidgets

QToolTip
--------

.. class:: QToolTip

    `C++ documentation <http://qt-project.org/doc/qt-5/qtooltip.html>`_
