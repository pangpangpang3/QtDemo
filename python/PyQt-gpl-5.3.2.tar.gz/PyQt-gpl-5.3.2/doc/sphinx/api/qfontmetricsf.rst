.. currentmodule:: PyQt5.QtGui

QFontMetricsF
-------------

.. class:: QFontMetricsF

    `C++ documentation <http://qt-project.org/doc/qt-5/qfontmetricsf.html>`_
