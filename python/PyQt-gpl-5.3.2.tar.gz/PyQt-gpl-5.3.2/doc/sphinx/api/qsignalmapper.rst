.. currentmodule:: PyQt5.QtCore

QSignalMapper
-------------

.. class:: QSignalMapper

    `C++ documentation <http://qt-project.org/doc/qt-5/qsignalmapper.html>`_
