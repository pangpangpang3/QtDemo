.. currentmodule:: PyQt5.QtWidgets

QDial
-----

.. class:: QDial

    `C++ documentation <http://qt-project.org/doc/qt-5/qdial.html>`_
