.. currentmodule:: PyQt5.QtWidgets

QMenu
-----

.. class:: QMenu

    `C++ documentation <http://qt-project.org/doc/qt-5/qmenu.html>`_
