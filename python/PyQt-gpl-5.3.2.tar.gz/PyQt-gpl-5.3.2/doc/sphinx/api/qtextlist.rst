.. currentmodule:: PyQt5.QtGui

QTextList
---------

.. class:: QTextList

    `C++ documentation <http://qt-project.org/doc/qt-5/qtextlist.html>`_
