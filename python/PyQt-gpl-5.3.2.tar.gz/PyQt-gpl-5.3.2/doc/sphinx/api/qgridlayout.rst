.. currentmodule:: PyQt5.QtWidgets

QGridLayout
-----------

.. class:: QGridLayout

    `C++ documentation <http://qt-project.org/doc/qt-5/qgridlayout.html>`_
