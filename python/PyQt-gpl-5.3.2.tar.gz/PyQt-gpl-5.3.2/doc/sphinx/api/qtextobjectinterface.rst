.. currentmodule:: PyQt5.QtGui

QTextObjectInterface
--------------------

.. class:: QTextObjectInterface

    `C++ documentation <http://qt-project.org/doc/qt-5/qtextobjectinterface.html>`_
