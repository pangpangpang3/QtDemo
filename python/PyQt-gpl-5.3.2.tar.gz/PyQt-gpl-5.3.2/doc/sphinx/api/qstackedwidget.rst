.. currentmodule:: PyQt5.QtWidgets

QStackedWidget
--------------

.. class:: QStackedWidget

    `C++ documentation <http://qt-project.org/doc/qt-5/qstackedwidget.html>`_
