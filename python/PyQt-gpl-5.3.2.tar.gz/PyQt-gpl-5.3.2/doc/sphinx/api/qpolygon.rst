.. currentmodule:: PyQt5.QtGui

QPolygon
--------

.. class:: QPolygon

    `C++ documentation <http://qt-project.org/doc/qt-5/qpolygon.html>`_
