.. currentmodule:: PyQt5.QtDesigner

QDesignerWidgetBoxInterface
---------------------------

.. class:: QDesignerWidgetBoxInterface

    `C++ documentation <http://qt-project.org/doc/qt-5/qdesignerwidgetboxinterface.html>`_
