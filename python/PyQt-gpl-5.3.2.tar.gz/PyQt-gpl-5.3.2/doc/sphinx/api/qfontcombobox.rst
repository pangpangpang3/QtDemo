.. currentmodule:: PyQt5.QtWidgets

QFontComboBox
-------------

.. class:: QFontComboBox

    `C++ documentation <http://qt-project.org/doc/qt-5/qfontcombobox.html>`_
