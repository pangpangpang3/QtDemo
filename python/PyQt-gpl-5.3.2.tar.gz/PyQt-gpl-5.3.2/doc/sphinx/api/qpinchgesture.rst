.. currentmodule:: PyQt5.QtWidgets

QPinchGesture
-------------

.. class:: QPinchGesture

    `C++ documentation <http://qt-project.org/doc/qt-5/qpinchgesture.html>`_
