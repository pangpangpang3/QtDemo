.. currentmodule:: PyQt5.QtGui

QIntValidator
-------------

.. class:: QIntValidator

    `C++ documentation <http://qt-project.org/doc/qt-5/qintvalidator.html>`_
