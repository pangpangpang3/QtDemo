.. currentmodule:: PyQt5.QtCore

QFileInfo
---------

.. class:: QFileInfo

    `C++ documentation <http://qt-project.org/doc/qt-5/qfileinfo.html>`_
