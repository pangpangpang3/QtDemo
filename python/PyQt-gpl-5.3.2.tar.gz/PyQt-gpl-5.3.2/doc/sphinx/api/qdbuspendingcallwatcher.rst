.. currentmodule:: PyQt5.QtDBus

QDBusPendingCallWatcher
-----------------------

.. class:: QDBusPendingCallWatcher

    `C++ documentation <http://qt-project.org/doc/qt-5/qdbuspendingcallwatcher.html>`_
