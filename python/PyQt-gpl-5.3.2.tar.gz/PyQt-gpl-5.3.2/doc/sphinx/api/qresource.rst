.. currentmodule:: PyQt5.QtCore

QResource
---------

.. class:: QResource

    `C++ documentation <http://qt-project.org/doc/qt-5/qresource.html>`_
