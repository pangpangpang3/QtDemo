.. currentmodule:: PyQt5.QtGui

QTextDocument
-------------

.. class:: QTextDocument

    `C++ documentation <http://qt-project.org/doc/qt-5/qtextdocument.html>`_
