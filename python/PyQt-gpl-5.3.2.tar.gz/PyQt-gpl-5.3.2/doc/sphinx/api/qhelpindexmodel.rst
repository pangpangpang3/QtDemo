.. currentmodule:: PyQt5.QtHelp

QHelpIndexModel
---------------

.. class:: QHelpIndexModel

    `C++ documentation <http://qt-project.org/doc/qt-5/qhelpindexmodel.html>`_
