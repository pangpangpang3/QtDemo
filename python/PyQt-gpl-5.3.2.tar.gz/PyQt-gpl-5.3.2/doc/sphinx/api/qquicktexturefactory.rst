.. currentmodule:: PyQt5.QtQuick

QQuickTextureFactory
--------------------

.. class:: QQuickTextureFactory

    `C++ documentation <http://qt-project.org/doc/qt-5/qquicktexturefactory.html>`_
