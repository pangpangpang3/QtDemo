.. currentmodule:: PyQt5.QtSensors

QRotationFilter
---------------

.. class:: QRotationFilter

    `C++ documentation <http://qt-project.org/doc/qt-5/qrotationfilter.html>`_
