.. currentmodule:: PyQt5.QtWebKit

QWebSettings
------------

.. class:: QWebSettings

    `C++ documentation <http://qt-project.org/doc/qt-5/qwebsettings.html>`_
