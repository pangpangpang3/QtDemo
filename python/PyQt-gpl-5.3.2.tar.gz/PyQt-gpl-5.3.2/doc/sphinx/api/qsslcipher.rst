.. currentmodule:: PyQt5.QtNetwork

QSslCipher
----------

.. class:: QSslCipher

    `C++ documentation <http://qt-project.org/doc/qt-5/qsslcipher.html>`_
