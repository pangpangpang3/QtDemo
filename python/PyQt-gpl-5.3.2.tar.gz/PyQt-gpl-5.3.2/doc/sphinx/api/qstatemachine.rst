.. currentmodule:: PyQt5.QtCore

QStateMachine
-------------

.. class:: QStateMachine

    `C++ documentation <http://qt-project.org/doc/qt-5/qstatemachine.html>`_
