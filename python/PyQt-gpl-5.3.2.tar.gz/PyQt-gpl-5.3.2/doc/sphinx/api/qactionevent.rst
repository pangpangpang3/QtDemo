.. currentmodule:: PyQt5.QtGui

QActionEvent
------------

.. class:: QActionEvent

    `C++ documentation <http://qt-project.org/doc/qt-5/qactionevent.html>`_
