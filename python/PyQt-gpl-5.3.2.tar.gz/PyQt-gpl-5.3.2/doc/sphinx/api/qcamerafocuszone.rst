.. currentmodule:: PyQt5.QtMultimedia

QCameraFocusZone
----------------

.. class:: QCameraFocusZone

    `C++ documentation <http://qt-project.org/doc/qt-5/qcamerafocuszone.html>`_
