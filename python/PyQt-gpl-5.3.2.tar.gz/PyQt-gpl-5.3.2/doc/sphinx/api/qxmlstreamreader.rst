.. currentmodule:: PyQt5.QtCore

QXmlStreamReader
----------------

.. class:: QXmlStreamReader

    `C++ documentation <http://qt-project.org/doc/qt-5/qxmlstreamreader.html>`_
