.. currentmodule:: PyQt5.QtCore

QChildEvent
-----------

.. class:: QChildEvent

    `C++ documentation <http://qt-project.org/doc/qt-5/qchildevent.html>`_
