.. currentmodule:: PyQt5.QtQuick

QSGTransformNode
----------------

.. class:: QSGTransformNode

    `C++ documentation <http://qt-project.org/doc/qt-5/qsgtransformnode.html>`_
