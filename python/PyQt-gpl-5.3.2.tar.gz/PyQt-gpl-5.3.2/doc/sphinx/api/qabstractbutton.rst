.. currentmodule:: PyQt5.QtWidgets

QAbstractButton
---------------

.. class:: QAbstractButton

    `C++ documentation <http://qt-project.org/doc/qt-5/qabstractbutton.html>`_
