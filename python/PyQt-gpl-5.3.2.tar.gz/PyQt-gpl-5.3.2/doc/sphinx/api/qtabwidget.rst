.. currentmodule:: PyQt5.QtWidgets

QTabWidget
----------

.. class:: QTabWidget

    `C++ documentation <http://qt-project.org/doc/qt-5/qtabwidget.html>`_
