.. currentmodule:: PyQt5.QtWidgets

QStyleOptionComboBox
--------------------

.. class:: QStyleOptionComboBox

    `C++ documentation <http://qt-project.org/doc/qt-5/qstyleoptioncombobox.html>`_
