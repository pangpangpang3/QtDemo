.. currentmodule:: PyQt5.QtCore

QStandardPaths
--------------

.. class:: QStandardPaths

    `C++ documentation <http://qt-project.org/doc/qt-5/qstandardpaths.html>`_
