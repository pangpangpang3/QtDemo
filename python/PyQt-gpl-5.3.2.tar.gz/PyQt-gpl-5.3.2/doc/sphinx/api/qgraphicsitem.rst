.. currentmodule:: PyQt5.QtWidgets

QGraphicsItem
-------------

.. class:: QGraphicsItem

    `C++ documentation <http://qt-project.org/doc/qt-5/qgraphicsitem.html>`_
