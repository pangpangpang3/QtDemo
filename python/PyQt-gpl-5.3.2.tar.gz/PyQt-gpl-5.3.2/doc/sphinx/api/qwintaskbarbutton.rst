.. currentmodule:: PyQt5.QtWinExtras

QWinTaskbarButton
-----------------

.. class:: QWinTaskbarButton

    `C++ documentation <http://qt-project.org/doc/qt-5/qwintaskbarbutton.html>`_
