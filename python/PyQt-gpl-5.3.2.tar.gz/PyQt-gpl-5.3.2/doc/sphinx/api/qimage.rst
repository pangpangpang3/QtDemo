.. currentmodule:: PyQt5.QtGui

QImage
------

.. class:: QImage

    `C++ documentation <http://qt-project.org/doc/qt-5/qimage.html>`_
