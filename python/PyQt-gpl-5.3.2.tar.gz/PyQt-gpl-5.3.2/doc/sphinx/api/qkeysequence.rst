.. currentmodule:: PyQt5.QtGui

QKeySequence
------------

.. class:: QKeySequence

    `C++ documentation <http://qt-project.org/doc/qt-5/qkeysequence.html>`_
