.. currentmodule:: PyQt5.QtWebSockets

QWebSocketCorsAuthenticator
---------------------------

.. class:: QWebSocketCorsAuthenticator

    `C++ documentation <http://qt-project.org/doc/qt-5/qwebsocketcorsauthenticator.html>`_
