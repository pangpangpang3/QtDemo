.. currentmodule:: PyQt5.QtWidgets

QVBoxLayout
-----------

.. class:: QVBoxLayout

    `C++ documentation <http://qt-project.org/doc/qt-5/qvboxlayout.html>`_
