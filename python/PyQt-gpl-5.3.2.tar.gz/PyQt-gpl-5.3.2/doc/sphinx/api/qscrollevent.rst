.. currentmodule:: PyQt5.QtGui

QScrollEvent
------------

.. class:: QScrollEvent

    `C++ documentation <http://qt-project.org/doc/qt-5/qscrollevent.html>`_
