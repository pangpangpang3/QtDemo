.. currentmodule:: PyQt5.QtPrintSupport

QPrinterInfo
------------

.. class:: QPrinterInfo

    `C++ documentation <http://qt-project.org/doc/qt-5/qprinterinfo.html>`_
