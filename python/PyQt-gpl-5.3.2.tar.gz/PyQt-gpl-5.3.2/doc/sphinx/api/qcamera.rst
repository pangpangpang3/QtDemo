.. currentmodule:: PyQt5.QtMultimedia

QCamera
-------

.. class:: QCamera

    `C++ documentation <http://qt-project.org/doc/qt-5/qcamera.html>`_
