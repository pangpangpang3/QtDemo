.. currentmodule:: PyQt5.QtGui

QOpenGLBuffer
-------------

.. class:: QOpenGLBuffer

    `C++ documentation <http://qt-project.org/doc/qt-5/qopenglbuffer.html>`_
