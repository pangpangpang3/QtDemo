.. currentmodule:: PyQt5.QtQuick

QSGClipNode
-----------

.. class:: QSGClipNode

    `C++ documentation <http://qt-project.org/doc/qt-5/qsgclipnode.html>`_
