.. currentmodule:: PyQt5.QtWidgets

QGesture
--------

.. class:: QGesture

    `C++ documentation <http://qt-project.org/doc/qt-5/qgesture.html>`_
