.. currentmodule:: PyQt5.QtCore

QMetaType
---------

.. class:: QMetaType

    `C++ documentation <http://qt-project.org/doc/qt-5/qmetatype.html>`_
