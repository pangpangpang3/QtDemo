.. currentmodule:: PyQt5.QtCore

QLineF
------

.. class:: QLineF

    `C++ documentation <http://qt-project.org/doc/qt-5/qlinef.html>`_
