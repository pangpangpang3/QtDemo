.. currentmodule:: PyQt5.QtSql

QSqlField
---------

.. class:: QSqlField

    `C++ documentation <http://qt-project.org/doc/qt-5/qsqlfield.html>`_
