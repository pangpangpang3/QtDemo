.. currentmodule:: PyQt5.QtCore

QStringListModel
----------------

.. class:: QStringListModel

    `C++ documentation <http://qt-project.org/doc/qt-5/qstringlistmodel.html>`_
