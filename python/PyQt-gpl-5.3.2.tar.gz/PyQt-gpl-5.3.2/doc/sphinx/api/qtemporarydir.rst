.. currentmodule:: PyQt5.QtCore

QTemporaryDir
-------------

.. class:: QTemporaryDir

    `C++ documentation <http://qt-project.org/doc/qt-5/qtemporarydir.html>`_
