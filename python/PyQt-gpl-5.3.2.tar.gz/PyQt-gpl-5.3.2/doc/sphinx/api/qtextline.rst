.. currentmodule:: PyQt5.QtGui

QTextLine
---------

.. class:: QTextLine

    `C++ documentation <http://qt-project.org/doc/qt-5/qtextline.html>`_
