.. currentmodule:: PyQt5.QtQuick

QSGGeometryNode
---------------

.. class:: QSGGeometryNode

    `C++ documentation <http://qt-project.org/doc/qt-5/qsggeometrynode.html>`_
