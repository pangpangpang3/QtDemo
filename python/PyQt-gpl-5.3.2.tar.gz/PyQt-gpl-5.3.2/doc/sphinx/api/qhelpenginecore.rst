.. currentmodule:: PyQt5.QtHelp

QHelpEngineCore
---------------

.. class:: QHelpEngineCore

    `C++ documentation <http://qt-project.org/doc/qt-5/qhelpenginecore.html>`_
