.. currentmodule:: PyQt5.QtGui

QGradient
---------

.. class:: QGradient

    `C++ documentation <http://qt-project.org/doc/qt-5/qgradient.html>`_
