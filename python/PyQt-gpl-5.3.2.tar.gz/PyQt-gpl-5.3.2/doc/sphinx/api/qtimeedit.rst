.. currentmodule:: PyQt5.QtWidgets

QTimeEdit
---------

.. class:: QTimeEdit

    `C++ documentation <http://qt-project.org/doc/qt-5/qtimeedit.html>`_
