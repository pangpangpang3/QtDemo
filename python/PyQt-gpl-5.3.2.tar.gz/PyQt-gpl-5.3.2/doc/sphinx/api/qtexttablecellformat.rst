.. currentmodule:: PyQt5.QtGui

QTextTableCellFormat
--------------------

.. class:: QTextTableCellFormat

    `C++ documentation <http://qt-project.org/doc/qt-5/qtexttablecellformat.html>`_
