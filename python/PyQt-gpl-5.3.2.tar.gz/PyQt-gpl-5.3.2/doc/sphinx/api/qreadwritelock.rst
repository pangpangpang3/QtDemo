.. currentmodule:: PyQt5.QtCore

QReadWriteLock
--------------

.. class:: QReadWriteLock

    `C++ documentation <http://qt-project.org/doc/qt-5/qreadwritelock.html>`_
