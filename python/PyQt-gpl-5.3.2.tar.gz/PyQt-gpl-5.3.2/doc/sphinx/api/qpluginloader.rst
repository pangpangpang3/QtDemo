.. currentmodule:: PyQt5.QtCore

QPluginLoader
-------------

.. class:: QPluginLoader

    `C++ documentation <http://qt-project.org/doc/qt-5/qpluginloader.html>`_
