.. currentmodule:: PyQt5.QtGui

QOpenGLFramebufferObjectFormat
------------------------------

.. class:: QOpenGLFramebufferObjectFormat

    `C++ documentation <http://qt-project.org/doc/qt-5/qopenglframebufferobjectformat.html>`_
