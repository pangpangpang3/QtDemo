.. currentmodule:: PyQt5.QtWinExtras

QWinJumpListCategory
--------------------

.. class:: QWinJumpListCategory

    `C++ documentation <http://qt-project.org/doc/qt-5/qwinjumplistcategory.html>`_
