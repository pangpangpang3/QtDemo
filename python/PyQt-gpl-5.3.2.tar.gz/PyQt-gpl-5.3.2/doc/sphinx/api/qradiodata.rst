.. currentmodule:: PyQt5.QtMultimedia

QRadioData
----------

.. class:: QRadioData

    `C++ documentation <http://qt-project.org/doc/qt-5/qradiodata.html>`_
