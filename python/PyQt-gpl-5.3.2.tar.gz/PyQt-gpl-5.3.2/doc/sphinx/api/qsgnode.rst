.. currentmodule:: PyQt5.QtQuick

QSGNode
-------

.. class:: QSGNode

    `C++ documentation <http://qt-project.org/doc/qt-5/qsgnode.html>`_
