.. currentmodule:: PyQt5.QtSql

QSqlRecord
----------

.. class:: QSqlRecord

    `C++ documentation <http://qt-project.org/doc/qt-5/qsqlrecord.html>`_
