.. currentmodule:: PyQt5.QtDesigner

QExtensionManager
-----------------

.. class:: QExtensionManager

    `C++ documentation <http://qt-project.org/doc/qt-5/qextensionmanager.html>`_
