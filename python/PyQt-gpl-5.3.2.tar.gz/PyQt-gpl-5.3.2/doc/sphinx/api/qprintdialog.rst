.. currentmodule:: PyQt5.QtPrintSupport

QPrintDialog
------------

.. class:: QPrintDialog

    `C++ documentation <http://qt-project.org/doc/qt-5/qprintdialog.html>`_
