.. currentmodule:: PyQt5.QtGui

QWhatsThisClickedEvent
----------------------

.. class:: QWhatsThisClickedEvent

    `C++ documentation <http://qt-project.org/doc/qt-5/qwhatsthisclickedevent.html>`_
