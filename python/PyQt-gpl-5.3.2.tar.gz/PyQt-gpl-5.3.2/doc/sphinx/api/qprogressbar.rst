.. currentmodule:: PyQt5.QtWidgets

QProgressBar
------------

.. class:: QProgressBar

    `C++ documentation <http://qt-project.org/doc/qt-5/qprogressbar.html>`_
