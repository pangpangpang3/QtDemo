.. currentmodule:: PyQt5.QtGui

QPainter
--------

.. class:: QPainter

    `C++ documentation <http://qt-project.org/doc/qt-5/qpainter.html>`_
