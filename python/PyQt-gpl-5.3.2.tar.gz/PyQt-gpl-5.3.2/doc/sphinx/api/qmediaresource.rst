.. currentmodule:: PyQt5.QtMultimedia

QMediaResource
--------------

.. class:: QMediaResource

    `C++ documentation <http://qt-project.org/doc/qt-5/qmediaresource.html>`_
