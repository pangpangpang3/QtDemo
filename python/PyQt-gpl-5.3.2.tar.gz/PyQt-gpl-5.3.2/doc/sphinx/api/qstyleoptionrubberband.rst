.. currentmodule:: PyQt5.QtWidgets

QStyleOptionRubberBand
----------------------

.. class:: QStyleOptionRubberBand

    `C++ documentation <http://qt-project.org/doc/qt-5/qstyleoptionrubberband.html>`_
