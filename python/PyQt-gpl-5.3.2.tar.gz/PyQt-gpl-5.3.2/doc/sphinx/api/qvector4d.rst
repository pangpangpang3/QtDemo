.. currentmodule:: PyQt5.QtGui

QVector4D
---------

.. class:: QVector4D

    `C++ documentation <http://qt-project.org/doc/qt-5/qvector4d.html>`_
