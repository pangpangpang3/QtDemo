PyQt5 Class Reference
=====================

This section contains the reference documentation for the classes and functions
implemented by :mod:`PyQt5`.  At the moment most of this consists of links to
the corresponding C++ documentation.  Future versions will include more
Pythonic documentation.

.. toctree::
    :glob:

    api/*
